<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Cifrado RSA</title>
    </head>
    <body>
        <h1>Cifrado Asimétrico RSA</h1>
        <form action="EncryptServlet" method="POST">
            <label for="mensaje">Mensaje:</label><br/>
            <textarea name="mensaje" id="mensaje" rows="4" cols="50"></textarea><br/><br/>
            <input type="submit" value="Cifrar" />
        </form>
    </body>
</html>
