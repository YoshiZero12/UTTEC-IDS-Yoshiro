<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Resultado RSA</title>
    </head>
    <body>
        <h1>Resultado</h1>
        <p><strong>Resultado:</strong> ${resultado}</p>
        <br/>
        <a href="DecryptServlet">Descifrar</a>
        &nbsp;&nbsp;
        <a href="index.jsp">Volver</a>
    </body>
</html>
